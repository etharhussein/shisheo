// Copyright 2019 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// ignore_for_file: public_member_api_docs
// ignore_for_file: unawaited_futures

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:restaurant_ui_kit/screens/home.dart';
import 'page.dart';

class MarkerIconsPage extends GoogleMapExampleAppPage {
  MarkerIconsPage() : super(const Icon(Icons.image), 'Marker icons');

  @override
  Widget build(BuildContext context) {
    return const MarkerIconsBody();
  }
}

class MarkerIconsBody extends StatefulWidget {
  const MarkerIconsBody();

  @override
  State<StatefulWidget> createState() => MarkerIconsBodyState();
}

const LatLng _kMapCenter = LatLng(25.18730704382186, 55.26062349207878);

class MarkerIconsBodyState extends State<MarkerIconsBody> {
  GoogleMapController controller;
  BitmapDescriptor _markerIcon;

  @override
  Widget build(BuildContext context) {
    _createMarkerImageFromAsset(context);
    return Scaffold(
      resizeToAvoidBottomPadding: true,
      body:  Column(

      mainAxisSize: MainAxisSize.max,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        SizedBox(height: 10.0),
        Card(
          elevation: 6.0,
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.all(
                Radius.circular(5.0),
              ),
            ),
            child: TextField(
              style: TextStyle(
                fontSize: 15.0,
                color: Colors.black,
              ),
              decoration: InputDecoration(
                contentPadding: EdgeInsets.all(10.0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(5.0),
                  borderSide: BorderSide(color: Colors.white,),
                ),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white,),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                hintText: "Search..",
                suffixIcon: Icon(
                  Icons.search,
                  color: Colors.black,
                ),
                hintStyle: TextStyle(
                  fontSize: 15.0,
                  color: Colors.black,
                ),
              ),
              maxLines: 1,

            ),
          ),
        ),
        Center(

          child: SizedBox(
            width: double.infinity,
            height: 500,
            child: GoogleMap(
              initialCameraPosition: const CameraPosition(
                target: _kMapCenter,
                zoom: 10.0,
              ),
              markers: _createMarker(),
              onMapCreated: _onMapCreated,
            ),
          ),
        )
      ],
    ),
        bottomNavigationBar:  new Theme(
        data: Theme.of(context).copyWith(
      // sets the background color of the `BottomNavigationBar`
      //canvasColor:  Color.fromRGBO(0, 134, 87, 1),
      // sets the active color of the `BottomNavigationBar` if `Brightness` is light
      //primaryColor: Colors.red,
        textTheme: Theme
            .of(context)
            .textTheme
            .copyWith(caption: new TextStyle(color: Colors.yellow))), // sets the inactive color of the `BottomNavigationBar`
    child: new BottomNavigationBar(
    items: <BottomNavigationBarItem>[
    BottomNavigationBarItem(icon: Icon(Icons.home, size: 35,
    color:  Colors.black), title: Text("")),
    BottomNavigationBarItem(
    icon: Icon(Icons.qr_code_scanner, size: 35,
    color:  Colors.white), title: Text("")),
    BottomNavigationBarItem(
    icon: Icon(
    Icons.add_location_alt_outlined,
    size: 35,
    color:  Colors.black,
    ),
    title: Text("")),

    ],
    //currentIndex: _selectedIndex,
    selectedItemColor: Color(0xFF334192),
    unselectedItemColor: Colors.grey,
    onTap: (index){
    switch(index){
    case 0:
    Navigator.push(context, new MaterialPageRoute(
    builder: (context) =>
    new Home())
    );
    break;
    case 1:
    print('hereeee');
    break;
    case 2:
    Navigator.push(context, new MaterialPageRoute(
    builder: (context) =>
    new MarkerIconsPage())
    );
    break;
    }
    },
    ),),);
  }

  Set<Marker> _createMarker() {
    // TODO(iskakaushik): Remove this when collection literals makes it to stable.
    // https://github.com/flutter/flutter/issues/28312
    // ignore: prefer_collection_literals
    return <Marker>[
      Marker(
        markerId: MarkerId("marker_1"),
        position: _kMapCenter,
        icon: _markerIcon,
      ),
    ].toSet();
  }

  Future<void> _createMarkerImageFromAsset(BuildContext context) async {
    if (_markerIcon == null) {
      final ImageConfiguration imageConfiguration =
          createLocalImageConfiguration(context, size: Size.square(10));
      BitmapDescriptor.fromAssetImage(
              imageConfiguration, 'assets/point.png')
          .then(_updateBitmap);
    }
  }

  void _updateBitmap(BitmapDescriptor bitmap) {
    setState(() {
      _markerIcon = bitmap;
    });
  }

  void _onMapCreated(GoogleMapController controllerParam) {
    setState(() {
      controller = controllerParam;
    });
  }
}
