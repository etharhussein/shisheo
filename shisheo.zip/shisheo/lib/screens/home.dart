import 'package:flutter/material.dart';
import 'package:restaurant_ui_kit/screens/marker_icons.dart' ;
import 'package:restaurant_ui_kit/widgets/slider_item.dart';
import 'package:restaurant_ui_kit/util/foods.dart';
import 'package:carousel_slider/carousel_slider.dart';



class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> with AutomaticKeepAliveClientMixin<Home>{

  List<T> map<T>(List list, Function handler) {
    List<T> result = [];
    for (var i = 0; i < list.length; i++) {
      result.add(handler(i, list[i]));
    }

    return result;
  }

  int _current = 0;


  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(

      body: Padding(
        padding: EdgeInsets.fromLTRB(10.0,0,10.0,0),
        child: ListView(
          children: <Widget>[
            Hero(
              tag: 'hero',
              child: Padding(
                padding: EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
                child: CircleAvatar(
                  backgroundColor: Colors.transparent,
                  radius: 60.0,
                  child: Image.asset('assets/unnamed.png'),

                ),
              ),

            ),
            SizedBox(height: 10.0),

            Card(
              elevation: 6.0,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(
                    Radius.circular(5.0),
                  ),
                ),
                child: TextField(
                  style: TextStyle(
                    fontSize: 15.0,
                    color: Colors.black,
                  ),
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.all(10.0),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(5.0),
                      borderSide: BorderSide(color: Colors.white,),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderSide: BorderSide(color: Colors.white,),
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    hintText: "Search..",
                    suffixIcon: Icon(
                      Icons.search,
                      color: Colors.black,
                    ),
                    hintStyle: TextStyle(
                      fontSize: 15.0,
                      color: Colors.black,
                    ),
                  ),
                  maxLines: 1,

                ),
              ),
            ),

            SizedBox(height: 5.0),

            //Slider Here

            CarouselSlider(
              height: MediaQuery.of(context).size.height/2.4,
              items: map<Widget>(
                foods,
                    (index, i){
                      Map food = foods[index];
                  return SliderItem(
                    img: food['img'],
                    isFav: false,
                    name: food['name'],
                    rating: 4.0,
                    raters: 23,
                  );
                },
              ).toList(),
              autoPlay: false,
//                enlargeCenterPage: true,
              viewportFraction: 1.0,
//              aspectRatio: 2.0,

            ),
            SizedBox(height: 10.0),
            CarouselSlider(
              height: MediaQuery.of(context).size.height/2.4,
              items: map<Widget>(
                foods,
                    (index, i){
                  Map food = foods1[index];
                  return SliderItem(
                    img: food['img'],
                    isFav: false,
                    name: food['name'],
                    rating: 5.0,
                    raters: 23,
                  );
                },
              ).toList(),
              autoPlay: false,
//                enlargeCenterPage: true,
              viewportFraction: 1.0,
//              aspectRatio: 2.0,
              onPageChanged: (index) {
                setState(() {
                  _current = index;
                });
              },
            ),

            SizedBox(height: 30),
            CarouselSlider(
              height: MediaQuery.of(context).size.height/2.4,
              items: map<Widget>(
                foods,
                    (index, i){
                  Map food = foods3[index];
                  return SliderItem(
                    img: food['img'],
                    isFav: false,
                    name: food['name'],
                    rating: 5.0,
                    raters: 23,
                  );
                },
              ).toList(),
              autoPlay: false,
//                enlargeCenterPage: true,
              viewportFraction: 1.0,
//              aspectRatio: 2.0,
              onPageChanged: (index) {
                setState(() {
                  _current = index;
                });
              },
            ),
          ],
        ),
      ),
        bottomNavigationBar:  new Theme(
    data: Theme.of(context).copyWith(
      // sets the background color of the `BottomNavigationBar`
        //canvasColor:  Color.fromRGBO(0, 134, 87, 1),
        // sets the active color of the `BottomNavigationBar` if `Brightness` is light
        //primaryColor: Colors.red,
        textTheme: Theme
            .of(context)
            .textTheme
            .copyWith(caption: new TextStyle(color: Colors.yellow))), // sets the inactive color of the `BottomNavigationBar`
    child: new BottomNavigationBar(
    items: <BottomNavigationBarItem>[
    BottomNavigationBarItem(icon: Icon(Icons.home, size: 35,
    color:  Colors.black), title: Text("")),
    BottomNavigationBarItem(
    icon: Icon(Icons.qr_code_scanner, size: 35,
    color:  Colors.white), title: Text("")),
    BottomNavigationBarItem(
    icon: Icon(
    Icons.add_location_alt_outlined,
    size: 35,
    color:  Colors.black,
    ),
    title: Text("")),

    ],
    //currentIndex: _selectedIndex,
    selectedItemColor: Color(0xFF334192),
    unselectedItemColor: Colors.grey,
    onTap: (index){
    switch(index){
    case 0:
    Navigator.push(context, new MaterialPageRoute(
    builder: (context) =>
    new Home())
    );
    break;
    case 1:
    print('hereeee');
    break;
    case 2:
    Navigator.push(context, new MaterialPageRoute(
    builder: (context) =>
    new MarkerIconsPage())
    );
    break;
    }
    },
    ),),
    );
  }

  @override
  bool get wantKeepAlive => true;
}
