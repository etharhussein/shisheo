import 'dart:async';
import 'package:google_maps_webservice/places.dart';
import 'package:flutter_google_places/flutter_google_places.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'place_detail.dart';

const kGoogleApiKey = "AIzaSyAHh1DbcQuC242LmpXNujiOV6EPL7pTPtQ";
GoogleMapsPlaces _places = GoogleMapsPlaces(apiKey: kGoogleApiKey);



class Map extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MapState();
  }
}

class MapState extends State<Map> {
  final homeScaffoldKey = GlobalKey<ScaffoldState>();
  GoogleMapController mapController;
  List<PlacesSearchResult> places = [];
  bool isLoading = false;
  String errorMessage;

  void _opencamera(){}
  @override
  Widget build(BuildContext context) {
    Widget expandedChild;
    if (isLoading) {
      expandedChild = Center(child: CircularProgressIndicator(value: null));
    } else if (errorMessage != null) {
      expandedChild = Center(
        child: Text(errorMessage),
      );
    } else {
      expandedChild = buildPlacesList();
    }

    return Scaffold(
        key: homeScaffoldKey,
        appBar: AppBar(
          backgroundColor: Color.fromRGBO(41, 47, 112, 1),
          automaticallyImplyLeading: false, // Don't show the leading button
          title: Row(

            mainAxisAlignment: MainAxisAlignment.start,
            // crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[

              FlatButton.icon(padding: EdgeInsets.fromLTRB(0.0,0.0, 30.0, 0.0), onPressed: () => Navigator.pop(context), icon: Icon(Icons.keyboard_arrow_left_outlined, color: Colors.white), label: new Text('Back',style: TextStyle(color: Colors.white))),

              FlatButton.icon( padding: EdgeInsets.fromLTRB(40.0,0.0, 0.0, 0.0),onPressed: null, icon: new Text('Map',style: TextStyle(color: Colors.white,fontSize:20)), label: new Text('')),

              IconButton(
                padding: EdgeInsets.fromLTRB(140.0,0.0, 0.0, 0.0),
                alignment: Alignment.center,

                icon: Icon(Icons.menu, color: Colors.white),
              ),
              // Your widgets here
            ],
          ),

        ),
        body: Column(
          children: <Widget>[
            Container(
              child: SizedBox(
                 // height: 200.0,
                  child:Text('Please Choose Your Nearby...',style: TextStyle(color: Colors.black,fontSize:14,height :4))),

            ),
            ListTile(
              title: Row(
                children: <Widget>[
                  Expanded(child: RaisedButton(
                    elevation: 5.0,
                    shape: new RoundedRectangleBorder(side: BorderSide(
                        color: Colors.black,
                        width: 1,
                        style: BorderStyle.solid
                    ),
                        borderRadius: new BorderRadius.circular(30.0)),
                    color: Colors.white,
                    padding: EdgeInsets.fromLTRB(40.0, 0.0, 0.0,00),
                    child: Row (children: [(new Text('Metro Station',textAlign:TextAlign.center,
                        style: new TextStyle(color: Color.fromRGBO(41, 47, 112, 1),fontSize: 12.0))
                    ),



                    ]),
                    onPressed: _opencamera,
                  )),
                  Expanded(child: RaisedButton(
                    elevation: 5.0,
                    shape: new RoundedRectangleBorder(side: BorderSide(
                        color: Colors.black,
                        width: 1,
                        style: BorderStyle.solid
                    ),
                        borderRadius: new BorderRadius.circular(30.0)),
                    color: Colors.white,
                    padding: EdgeInsets.fromLTRB(40.0, 0.0, 0.0,00),
                    child: Row (children: [(new Text('Bus Station',textAlign:TextAlign.center,
                        style: new TextStyle(color: Color.fromRGBO(41, 47, 112, 1),fontSize: 12.0))
                    ),



                    ]),
                    onPressed: _opencamera,
                  )),
                ],
              ),
            ),

           Container(
              child: SizedBox(
                  height: 200.0,
                  child: GoogleMap(
                      onMapCreated: _onMapCreated,
                      options: GoogleMapOptions(
                          myLocationEnabled: true,
                          cameraPosition:
                              const CameraPosition(target: LatLng(0.0, 0.0))))),
            ),
          /*  Container(
              width: MediaQuery.of(context).size.width,
              height: MediaQuery.of(context).size.height - 213,
              decoration: BoxDecoration(
                image: DecorationImage(
                  fit: BoxFit.fill,
                  image: new ExactAssetImage('assets/map.png')
                ),
              ),
            ),*/
            Expanded(child: expandedChild)
          ],
        ));
  }

  void refresh() async {
    final center = await getUserLocation();

    mapController.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(
        target: center == null ? LatLng(0, 0) : center, zoom: 15.0)));
    getNearbyPlaces(center);
  }

  void _onMapCreated(GoogleMapController controller) async {
    mapController = controller;
    refresh();
  }

  Future<LatLng> getUserLocation() async {
    Location currentLocation ;//= <String, double>{};
    Location location = new Location(1.1, 1.2);
    try {
     // currentLocation = <String, double>{} as Location;

      //final lat = currentLocation.latitude;
     // final lng = currentLocation.longitude;
      final center = LatLng(1.1, 1.2);
      return center;
    } on Exception {
      currentLocation = null;
      return null;
    }
  }

  void getNearbyPlaces(LatLng center) async {
    setState(() {
      this.isLoading = true;
      this.errorMessage = null;
    });

    final location = Location(center.latitude, center.longitude);
    final result = await _places.searchNearbyWithRadius(location, 2500);
    setState(() {
      this.isLoading = false;
      if (result.status == "OK") {
        this.places = result.results;
        result.results.forEach((f) {
          final markerOptions = MarkerOptions(
              position:
                  LatLng(f.geometry.location.lat, f.geometry.location.lng),
              infoWindowText: InfoWindowText("${f.name}", "${f.types?.first}"));
          mapController.addMarker(markerOptions);
        });
      } else {
        this.errorMessage = result.errorMessage;
      }
    });
  }

  void onError(PlacesAutocompleteResponse response) {
    homeScaffoldKey.currentState.showSnackBar(
      SnackBar(content: Text(response.errorMessage)),
    );
  }

  Future<void> _handlePressButton() async {
    try {
      final center = await getUserLocation();
      Prediction p = await PlacesAutocomplete.show(
          context: context,
          strictbounds: center == null ? false : true,
          apiKey: kGoogleApiKey,
          onError: onError,
          mode: Mode.fullscreen,
          language: "en",
          location: center == null
              ? null
              : Location(center.latitude, center.longitude),
          radius: center == null ? null : 10000);

      showDetailPlace(p.placeId);
    } catch (e) {
      return;
    }
  }

  Future<Null> showDetailPlace(String placeId) async {
    if (placeId != null) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => PlaceDetailWidget(placeId)),
      );
    }
  }

  ListView buildPlacesList() {
    final placesWidget = places.map((f) {
      List<Widget> list = [
        Padding(
          padding: EdgeInsets.only(bottom: 4.0),
          child: Text(
            f.name,
            style: Theme.of(context).textTheme.subtitle,
          ),
        )
      ];
      if (f.formattedAddress != null) {
        list.add(Padding(
          padding: EdgeInsets.only(bottom: 2.0),
          child: Text(
            f.formattedAddress,
            style: Theme.of(context).textTheme.subtitle,
          ),
        ));
      }

      if (f.vicinity != null) {
        list.add(Padding(
          padding: EdgeInsets.only(bottom: 2.0),
          child: Text(
            f.vicinity,
            style: Theme.of(context).textTheme.body1,
          ),
        ));
      }

      if (f.types?.first != null) {
        list.add(Padding(
          padding: EdgeInsets.only(bottom: 2.0),
          child: Text(
            f.types.first,
            style: Theme.of(context).textTheme.caption,
          ),
        ));
      }

      return Padding(
        padding: EdgeInsets.only(top: 4.0, bottom: 4.0, left: 8.0, right: 8.0),
        child: Card(
          child: InkWell(
            onTap: () {
              showDetailPlace(f.placeId);
            },
            highlightColor: Colors.lightBlueAccent,
            splashColor: Colors.red,
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: list,
              ),
            ),
          ),
        ),
      );
    }).toList();

    return ListView(shrinkWrap: true, children: placesWidget);
  }
}
