List<Map> foods = [
  {
    "img": "assets/food1.jpeg",
    "name": "Fruit Salad"
  },

];

List<Map> foods1 = [

  {
    "img": "assets/food2.jpeg",
    "name": "Blue Beery"
  },

];
List<Map> foods3 = [

  {
    "img": "assets/food3.jpeg",
    "name": "Hamburger"
  },

];